import os,sys

outf=open('DeepProm1_promoters_nEC.csv','w')
inpf=open('Candidate_promoters_nEC.csv','r')
for line in inpf:
    val=line.rstrip()
    val0='\''+val.split(',')[0]+'\''
    Tier1file='Tier1_prediction.txt'
    os.system('grep %s %s > tmp' % (val0,Tier1file))
    f1=open('tmp','r')
    for line in f1:
        val1=line.rstrip().split(',')
        if val1[1].rstrip()=='Promoter':
            outf.write(val+'\n')
    f1.close()
inpf.close()
outf.close()
os.system('rm -rf tmp')
