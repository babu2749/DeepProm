import sys
# Input files
seqf=sys.argv[1] # Sequence information 
gnom_name=sys.argv[2] # Genome name
strain=sys.argv[3] # Strain name
gbf=sys.argv[4]  # Gene positions

# Genomic Sequence 
f1=open(seqf,'r')
SEQ=f1.read().split('\n')[1]
f1.close()

# Filtered Gene positions
f2=open(gbf,'r')
allvals=f2.read().split('\n')[1:-1]
f2.close()

# complementary bases
cb={'a':'t','t':'a','g':'c','c':'g'}

outf=open(gnom_name+'_Candidate_promoters.txt','w')
genomic_start=[]
genomic_end=[]

for i1 in allvals:
    val1=i1.split('\t')
    genomic_start.append(val1[0])
    genomic_end.append(val1[1])
#print(len(gene_start))
#print(len(gene_end))

x=0
while x < len(allvals):
    if x==0:
        val2=allvals[0].split('\t')
        
        # extract gene information
        start=val2[0]
        end=val2[1]
        gene_type=val2[2]
        
        # explore feasibility of evaluation
        if int(start) > 100:
            if gene_type=='R':
                prom=''
                for i in range(81):
                    prom=SEQ[int(start)-2-i].lower()+prom
                if prom != '' and len(prom)==81:
                    outf.write('>'+gnom_name+'_'+strain+'_gene_'+str(start)+'..'+str(end)+'|Forward'+'\n')
                    outf.write(prom+'\n')
            elif gene_type=='C':
                prom=''
                for j in range(81):
                    prom=prom+cb[SEQ[int(end)+j]]
                if prom != '' and len(prom)==81:
                    outf.write('>'+gnom_name+'_'+strain+'_gene_'+str(start)+'..'+str(end)+'|Reverse'+'\n')
                    outf.write(prom+'\n')

    elif 0 < x < len(allvals)-1:

        # current gene information
        val2=allvals[x].split('\t')
        start=val2[0]
        end=val2[1]
        gene_type=val2[2]

        # previous gene information
        prev_start=allvals[x-1].split('\t')[0]
        prev_end=allvals[x-1].split('\t')[1]
        prev_gene_type=allvals[x-1].split('\t')[2]

        # next gene information
        next_start=allvals[x+1].split('\t')[0]
        next_end=allvals[x+1].split('\t')[1]
        next_gene_type=allvals[x+1].split('\t')[2]


       
        if int(start)-int(prev_end) > 100:
            if gene_type=='C':
                if int(next_start)-int(end) > 100:
                    prom_f=SEQ[int(end):int(end)+81]
                    prom=''
                    for j in prom_f:
                        prom=prom+cb[j]
                    #print(len(prom))
                    if len(prom)==81:
                        outf.write('>'+gnom_name+'_'+strain+'_gene_'+str(start)+'..'+str(end)+'|Reverse'+'\n')
                        outf.write(prom+'\n')
            else:
               prom=SEQ[int(start)-82:int(start)-1]
               if len(prom)==81:
                    outf.write('>'+gnom_name+'_'+strain+'_gene_'+str(start)+'..'+str(end)+'|Forward'+'\n')
                    outf.write(prom+'\n')
    elif x==len(allvals)-1:
        # current gene information
        val2=allvals[x].split('\t')
        start=val2[0]
        end=val2[1]
        gene_type=val2[2]

        # previous gene information
        prev_start=allvals[x-1].split('\t')[0]
        prev_end=allvals[x-1].split('\t')[1]
        if int(start)-int(prev_end) > 100:
            if gene_type=='C':
                prom_f=SEQ[int(end):int(end)+81]
                prom=''
                for j in prom_f:
                    prom=prom+cb[j]
                #print(len(prom))
                if len(prom)==81:
                    outf.write('>'+gnom_name+'_'+strain+'_gene_'+str(start)+'..'+str(end)+'|Reverse'+'\n')
                    outf.write(prom+'\n')
            else:
               prom=SEQ[int(start)-82:int(start)-1]
               if len(prom)==81:
                    outf.write('>'+gnom_name+'_'+strain+'_gene_'+str(start)+'..'+str(end)+'|Forward'+'\n')
                    outf.write(prom+'\n')
        
    x=x+1
outf.close()
