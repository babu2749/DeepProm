import os,sys

genome_name=sys.argv[1]
outf=open(genome_name+'_DeepProm1_promoters_nEC.csv','w')
inpf=open(genome_name+'_Candidate_promoters_nEC.csv','r')
for line in inpf:
    val=line.rstrip()
    val0='\''+line.rstrip().split(',')[0]+'\''
    #print(val0)
    Tier1file='Tier1_prediction_'+genome_name+'.txt'
    os.system('grep %s %s > tmp' % (val0,Tier1file))
    f1=open('tmp','r')
    for line in f1:
        val1=line.rstrip().split(',')
        if val1[1].rstrip()=='Promoter':
            outf.write(val+'\n')
    f1.close()
    os.system('rm -rf tmp')
inpf.close()
outf.close()
