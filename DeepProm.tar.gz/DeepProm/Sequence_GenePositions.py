import sys

Fname = sys.argv[1]
outFname=Fname.split('.gbff')[0]+'_GenePositions.txt'

seqF=open(Fname,'r')
outf=open(outFname,'w')
gene_inf=seqF.read().split('FEATURES')
#print (gene_inf[1])


gene_inf2 = gene_inf[1].split('ORIGIN')
gene_inf3 = gene_inf2[0].split('\n')
#print (gene_inf3)


alph_l=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
alph_u=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
num=['1','2','3','4','5','6','7','8','9','0']
allowed_chr=['.','(',')']
#=======================================   GENE INFO   =================================================#
outf.write("start_position\tend_position\tgene_type\tgene_strand\n")
if len(gene_inf3) > 1:
    x=0
    while x < len(gene_inf3):
        gene_inf4=gene_inf3[x].split()
        if len(gene_inf4)==2 and gene_inf4[0].strip()=='gene' and gene_inf4[1].count('..')==1:
            start=''
            end=''
            gt=''
            gs=''        
            if gene_inf4[1].count('complement')==1:
                if gene_inf4[1].count('>')==0 and gene_inf4[1].count('<')==0:
                    #print(gene_inf4[1])
                    val1=gene_inf4[1].split('complement')[1].split('..')
                    start=val1[0][1:]
                    end=val1[1][:-1]
                    gt='C'
                    gs='S-'
                    outf.write(start+'\t'+end+'\t'+gt+'\t'+gs+'\n')
            else:
                if gene_inf4[1].count('>')==0 and gene_inf4[1].count('<')==0:
                    tmpval=''
                    for i1 in gene_inf4[1]:
                        if (i1 not in alph_l) and (i1 not in alph_u):
                            if (i1 in num) or (i1 in allowed_chr):
                                tmpval=tmpval+i1
                    if tmpval !='':
                        val2=tmpval.split('..')
                        start=val2[0]
                        end=val2[1]
                        gt='R' 
                        gs='S+'
                        outf.write(start+'\t'+end+'\t'+gt+'\t'+gs+'\n')
        x=x+1
outf.close()
#=======================================================================================================#


#===================================   SEQUENCE   = ====================================================#
gene_inf5= gene_inf2[1].split('\n')
SEQ=''
for i2 in gene_inf5:
    if i2.count('\\')==0 and i2 !='':
        val3=i2.split()
        for i3 in val3[1:]:
            if i3 !="":
                SEQ=SEQ+i3.strip()
outF1=open(Fname.split('.')[0]+'.fasta','w')
outF1.write('>'+Fname.split('.')[0]+'\n')
outF1.write(SEQ+'\n')
outF1.close() 


seqF.close()
outF1.close()
