# Pre- requisites
import os
import sys
import numpy as np
import pandas as pd
from keras import metrics
from keras.backend import cast_to_floatx
from sklearn.model_selection import train_test_split, KFold
from keras.models import Sequential, model_from_json
from keras.layers import Dense, Activation, Conv1D, MaxPooling1D, Flatten, Dropout
from keras.utils import np_utils
from keras.utils import to_categorical
from keras.layers import Dense, Activation, Conv1D, MaxPooling1D, Flatten, Dropout
from keras.utils import np_utils, plot_model
from keras.utils import to_categorical

# genome name
genome_name=sys.argv[1]

# Model
json_file = open('MulticlassCNNmodel_bacPromsub.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)

# load weights into new model
loaded_model.load_weights("MulticlassCNNmodel_bacPromsub.h5")
print ("Loaded model from disk")
#print (loaded_model.summary())
# compile model
loaded_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# evaluate loaded model on test data
dataframe1=pd.read_csv(genome_name+"_DeepProm1_promoters_nEC.csv", header=None)
dataset1=dataframe1.values
Allprom_te = cast_to_floatx(np_utils.to_categorical(np.array(dataset1[:,1:82])))
Multiclass_score = loaded_model.predict(Allprom_te)
#print (Multiclass_score)

# Generate output file of results
outf=open('Tier2_prediction'+'_'+genome_name+'.txt','w')
outf.write('# DeepProm Tier2 predictions\n')
outf.write('# Format for interpreting results:\n')
outf.write('# Promoter candidate,Prediction\n') 
allvals=[]
inf=open(genome_name+'_DeepProm1_promoters_nEC.csv','r')
for line in inf:
    allvals.append(line.rstrip().split(',')[0].rstrip())
inf.close()
cnt=0
while cnt < len(allvals):
    if round(Multiclass_score[cnt][0],1)== 1.0:
        outf.write(allvals[cnt].rstrip()+','+'Sigma-24 Promoter'+'\n')
    elif round(Multiclass_score[cnt][1],1)==1.0: 
        outf.write(allvals[cnt].rstrip()+','+'Sigma-28 Promoter'+'\n')
    elif round(Multiclass_score[cnt][2],1)==1.0: 
        outf.write(allvals[cnt].rstrip()+','+'Sigma-32 Promoter'+'\n')
    elif round(Multiclass_score[cnt][3],1)==1.0: 
        outf.write(allvals[cnt].rstrip()+','+'Sigma-38 Promoter'+'\n')
    elif round(Multiclass_score[cnt][4],1)==1.0: 
        outf.write(allvals[cnt].rstrip()+','+'Sigma-54 Promoter'+'\n')
    elif round(Multiclass_score[cnt][5],1)==1.0: 
        outf.write(allvals[cnt].rstrip()+','+'Sigma-70 Promoter'+'\n')
    else:
        outf.write(allvals[cnt].rstrip()+','+'Cannot be determined'+'\n')
    cnt=cnt+1
outf.close()
print('Prediction results are ready\n')
