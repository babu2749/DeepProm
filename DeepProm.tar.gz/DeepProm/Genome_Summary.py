import sys
import numpy as np
# input relevant gene positions file
fname=sys.argv[1]

cDNA_len=[]
gene_len=[]
intergenic_dist=[]
overlap_genes=[]
potential_operons=[]

f1=open(fname,'r')
allvals=f1.read().split('\n')[1:-1]
f1.close()

outfname=fname.split('_genomic_GenePositions.txt')[0]+'_summary.txt'
outf=open(outfname,'w')


Minus_cnt=0
Plus_cnt=0

x=0
while x < len(allvals):    
    val1=allvals[x].rstrip().split()
    
    # Minus strand genes
    if val1[-1]=='S-':
        Minus_cnt=Minus_cnt+1
    
    # Plus strand genes
    if val1[-1]=='S+':
        Plus_cnt=Plus_cnt+1
    
    # if cDNA, length
    if val1[2]=='C':
        cDNA_len.append(int(val1[1])-int(val1[0]))
         
    # gene length
    gene_len.append(int(val1[1])-int(val1[0]))
    
    # intergenic distcance
    if x == 0:
        # start at 0
        prev_start=0
        # current gene position
        current_start=int(val1[0])
        current_end=int(val1[1])
        intergenic_dist.append(current_start-prev_start)
    elif x > 1:
        # previous gene positions
        prev_start=int(allvals[x-1].split()[0])
        prev_end=int(allvals[x-1].split()[1])
        
        # current gene positions
        current_start=int(val1[0])
        current_end=int(val1[1])
        
        intergenic_dist.append(current_start-prev_end)
        if current_start-prev_end <= 0:
            overlap_genes.append(val1[0]+'-'+val1[1])
        elif current_start-prev_end < 100:
            potential_operons.append(val1[0]+'-'+val1[1])
    x=x+1

overlap=''
if len(overlap_genes) ==0:
    overlap='None as per collected information by this method'
elif len(overlap_genes) > 0:
    for o1 in overlap_genes:
        overlap=overlap+(o1)+','
operon=''
if len(potential_operons) ==0:
    operon='None as per collected information by this method'
elif len(potential_operons) > 0:
    for o2 in potential_operons:
        operon=operon+(o2)+','

outf.write('Number of minus strand genes: '+str(Minus_cnt)+'\n')
outf.write('Number of plus strand genes: '+str(Plus_cnt)+'\n')
outf.write('Average length of genes: '+str(np.mean(gene_len))+'\n')
outf.write('Minimum length of genes: '+str(min(gene_len))+'\n')
outf.write('Maximum length of genes: '+str(max(gene_len))+'\n')
outf.write('Average length of cDNA: '+str(np.mean(cDNA_len))+'\n')
outf.write('Minimum length of cDNA: '+str(min(cDNA_len))+'\n')
outf.write('Maximum length of cDNA: '+str(max(cDNA_len))+'\n')
outf.write('Average intergenic distance: '+str(np.mean(intergenic_dist))+'\n')
outf.write('Number of potentially overlapping genes: '+str(len(overlap_genes))+'\n')
outf.write('Number of potential operons: '+str(len(potential_operons))+'\n')
outf.write('Potential overlapping genes: '+overlap[:-1]+'\n')
outf.write('Potential operons: '+operon[:-1]+'\n')
outf.close()
