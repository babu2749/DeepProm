
# Input candidate promoter file
inpf=open('Candidate_promoters.txt','r')
allproms=inpf.read().split('>')[1:]
inpf.close()

# Output encoded file
Outf=open('Candidate_promoters_nEC.csv','w')
for i1 in allproms:
    val1=i1.split('\n')
    Cprom_name=val1[0]
    Cprom_seq=val1[1]

    # Numerical encoding
    Nucleotide={'a':'0','t':'1','g':'2','c':'3'}
    Cprom_encoded_seq=''
    for i2 in Cprom_seq:
        Cprom_encoded_seq=Cprom_encoded_seq+Nucleotide[i2]+','
    Outf.write(Cprom_name+','+Cprom_encoded_seq[:-1].rstrip()+'\n')
Outf.close()
